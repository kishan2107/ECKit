function openNav() {
    document.getElementById("mySidenav").style.width = "250px"; //Default: 250px. Edit to your liking.
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}